FORM / IKEA reference collection

Twenty IKEA references plus three original Homebuddy TV assemblies. Original TVs are design assets, not retail products, and their preview images are renders. IKEA pieces include original catalog photo URLs and independent photo-based 3D recreations. Photography and product designs belong to IKEA. This catalog is not affiliated with IKEA and these models are not official manufacturer CAD.

Each folder includes a Blender studio scene, furniture-only GLB model, recreation render and metadata with official product/photo links. PNG files are renders, NOT catalog photographs. Catalog photographs are loaded from IKEA in the viewer and are not included in this archive. Refer to the linked IKEA page for current product specifications.
